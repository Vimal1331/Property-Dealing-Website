// function debounceWithContext(func, timeout = 300){
//     let timer;
//     return function(...args) {
//       clearTimeout(timer);
//       timer = setTimeout(() => { func.apply(this, args); }, timeout);
//     };
//   }

function updateSliderEffect(ele){
    var maxValue = +$(ele.closest('.form-group')).find('.maxLimit').text();
    if(maxValue && +ele.value > maxValue){
      ele.value = maxValue;
    }
    var val = ($(ele).val() - $(ele).attr('min')) / ($(ele).attr('max') - $(ele).attr('min'));
    if(!ele.value){
      val = 0;
    }
    $(ele).css('background-image',
      '-webkit-gradient(linear, left top, right top, '
      + 'color-stop(' + val + ', #00B852), '
      + 'color-stop(' + val + ', #eaeaea)'
      + ')'
    );
  }
  
//   var valueRangeSlider = $('input.input-slider[type="range"]');
//   for(var el=0;el<valueRangeSlider.length;el++){
//     var valueSlider = ($(valueRangeSlider[el]).attr('value') - $(valueRangeSlider[el]).attr('min')) / ($(valueRangeSlider[el]).attr('max') - $(valueRangeSlider[el]).attr('min'));
//     $(valueRangeSlider[el]).css('background-image',
//       '-webkit-gradient(linear, left top, right top, '
//       + 'color-stop(' + valueSlider + ', #00B852), '
//       + 'color-stop(' + valueSlider + ', #eaeaea)'
//       + ')'
//     );
//   }
  
//   $('input.input-amount[type="range"], input.input-period[type="range"]').on('input', function (e){
//       updateSliderEffect(e.currentTarget);
//     var allocationPercentage = e.currentTarget.value;
//     var inpEl = $(e.currentTarget).parents().eq(1).prev().find('input[type="tel"]');
//     if(!inpEl.length){
//         inpEl = $(e.currentTarget).parents().eq(1).prev().find('input[type="number"]');
//     } 
//     inpEl.val(convertToLacsAndCrores(allocationPercentage));
//     inpEl.attr('data-value', commaSeparatorCurrency(allocationPercentage));
//     if(e.currentTarget.classList.contains('input-period')){
//         domElem.yearProp.style.left = 10 + 12 * (allocationPercentage + '').length + "px";
//     }
//     debounceWithContext(reset, 200)();
//   });
  
//   $(".calci-input-ctrl input").on('input', function (e){
//     var maxValue = +$(this.closest('.form-group')).find('.maxLimit').text() || 10000000;
//     $(this).val($(this).val().replace(/[^0-9]/g, ''));
//     if(+this.value > maxValue && this.value.length){
//       this.value = this.value.substring(0,this.value.length - 1);
//     }
//     var setValue = this.value;
//     var inputRange = $(this.closest('.form-group')).find('input[type="range"]');
//     inputRange.val(setValue);
//     updateSliderEffect(inputRange[0]);
//     debounceWithContext(reset, 200)();
//   });
  
//   $('input.input-growth[type="range"]').on('input', function (e){
//       updateSliderEffect(e.currentTarget);
//     var allocationPercentage = this.value;
//     var inpEl = $(this).parents().eq(1).prev().find('input[type="number"]');
//     inpEl.val(allocationPercentage);
//     interest = allocationPercentage;
//     domElem.percentageProp.style.left = 10 + 10 * (allocationPercentage + '').length + "px";
//     debounceWithContext(reset, 200)();
//   });
  
//   $(".calci-num-ctrl input").on('input', function (e){
//     var maxValue = +$(this.closest('.form-group')).find('.maxLimit').text() || 90;
//     $(this).val($(this).val().replace(/[^0-9]/g, ''));
//     if(+this.value > maxValue && this.value.length){
//       this.value = this.value.substring(0,this.value.length - 1);
//     }
//     var setValue = this.value;
//     var inputRange = $(this.closest('.form-group')).find('input[type="range"]');
//     inputRange.val(setValue);
//     updateSliderEffect(inputRange[0]);
//     if(e.currentTarget.name == 'period'){
//         domElem.yearProp.style.left = 10 + 12 * (setValue + '').length + "px";
//     } else if(e.currentTarget.name == 'interest'){
//         domElem.percentageProp.style.left = 10 + 10 * (setValue + '').length + "px";
//     }
//     debounceWithContext(reset, 200)();
//   });
  
  window.addEventListener("load", windowLoadCallback);
    var type = 'investmentDetails',
        calculationType='Investment',
        domElem, period, interest = 12,
        tenure = 5,
        chart,
        principal = 5000,
        selectedPeriod = "Yearly",
        compoundAmount = 412431.83,
        compoundInterest = 112432,
        compoundInterval = 1,
        additionalAmount = 0,
        additionalYear = 0,
        isAdditionalAmount = false,
        isInflation = false,
        inflationRate = 4,
        mainMonthlyAmount,
        primaryCategory = 'EQUITY',
        displayType = 'Form';

    function windowLoadCallback() {
        setTimeout(()=>{
            webengageCustomEvent("sv calculator sip landing", {
                SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                Platform: (isMobileDevice() ? 'M web' : 'Web'),
            });
        },1000);
        if(window.innerWidth < 991){
             $('.calculation-content').hide();
             $('.calculation-content').removeClass('hidden-xs');
        }
        domElem = {
                amountElem: document.querySelector('input[name="amount"]'),
                interestElem: document.querySelector('input[name="interest"]'),
                TimePeriod: document.querySelector('input[name="period"]'),
                invesdtedAmount: document.querySelector("#invesdtedAmount span"),
                InterestGain: document.querySelector("#InterestGain span"),
                maturityAmount: document.querySelector("#maturityAmount span"),
                graphBody: document.querySelector(".graphic-body"),
                postTax: document.querySelector("input[name='post_tax']"),
                seniorCitizen: document.querySelector("input[name='senior_citizen']"),
                extraInterest: document.getElementById("extraInterest"),
                extraInterestProp: document.getElementById("extraInterestProp"),
                postTaxBlock: document.querySelector(".post-tax-block"),
                percentageProp: document.querySelector(".input-prop.percentage"),
                yearProp: document.querySelector(".input-prop.year"),
                resultBlock: document.querySelector("#fd_result"),
                engagementTip: document.querySelector(".helping-info .main"),
                leftLabel: document.querySelector(".graphic-body .left-up-arrow"),
                rightLabel: document.querySelector(".graphic-body .right-up-arrow"),
            },
            setAllSliders();
            DrawChart(),generateAmountLabels(),
            // callAPI(primaryCategory, tenure),
            document.getElementById("calculate").addEventListener("click", (function(e) {
                allInputvalid() && 
                (domElem.InterestGain.setAttribute("data-prevalue", Math.round(compoundInterest / 3)),
                    domElem.maturityAmount.setAttribute("data-prevalue", Math.round(compoundAmount / 3)),
                    updateOutput())
                if (allInputvalid() && window.outerWidth < 991) {
                    $('.cal-tax-exemption').hide();
                    $('.sec-calculator .top-heading').hide();
                    $('.calculation-content').show();
                    $("html, body").animate({
                        scrollTop: 0 //$(".calculation-result").offset().top - 60
                    }, 500);
                    
                    displayType = 'Output';
                    webengageCustomEvent("sv calculator sip output", {
                        SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                        Platform: (isMobileDevice() ? 'M web' : 'Web'),
                    });
                }
                // window.outerWidth < 991 && $("html, body").animate({
                //     scrollTop: $(".calculation-result").offset().top - 60
                // }, 500)),
                customGaEvents('Calculator', pageName + 'CTA Click', e.target.innerText);
                webengageCustomEvent("sa calculator sip calculate", {
                    SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                    Platform: (isMobileDevice() ? 'M web' : 'Web'),
                    CTAName: "Calculate"
                });
            }))

        document.getElementById("edit_details").addEventListener("click", function(e) {
            $('.sec-calculator .top-heading').show();
            $('.cal-tax-exemption').show();
            $('.calculation-content').hide();
            $("html, body").animate({
                scrollTop: 0
            }, 500);
            
            displayType = 'Form';
            webengageCustomEvent("sa calculator sip edit details", {
                SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                Platform: (isMobileDevice() ? 'M web' : 'Web'),
                CTAName: "Edit Details"
            });
        });

        $('#show_earn_more').click(function(e) {
            $('#show_earn_more_parent').addClass('hidden');
            $('#earn_more').removeClass('hidden');
            isAdditionalAmount = true;
            if($('.tenure-label').hasClass('active')) {
                $('#amount_yr_toggle').click();
            }
            document.querySelector(".year-values").classList.add("hide");
            document.querySelector(".amount-values").classList.remove("hide");
            // updateOutput();
            webengageCustomEvent("sa calculator sip see how cta", {
                SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                Platform: (isMobileDevice() ? 'M web' : 'Web'),
                CTAName: "See how"
            });
        });

        $('.detailType input[type="radio"]').click(function() {
            type = $(this).attr("value");
            var rangeELem = document.querySelector('input.input-amount[type="range"]');
            if (type == 'investmentDetails') {
                $('.graphic-body').addClass('bar-graphic-body');
                /*if (window.outerWidth > 991) {
                    $('.chart-box').css('height', "80%");
                }*/
                $(domElem.amountElem).val("5,000"),
                $(domElem.amountElem).attr('data-value', "5000"),
                $(domElem.amountElem).attr('data-max', "100000"),
                $(domElem.amountElem).attr('maxlength', "8")
                $(rangeELem).attr('max', '100000');
                $(rangeELem).val('5000');
                // $('.amount-form-group .calci-amount').text(capitalizeFirstLetter(valueInWords(5000)) + " only");
                $('.calci-amount').removeClass('error-msg');
                $('.calci-input-ctrl').removeClass('error-in');
                outputContainer.classList.remove("overlay");

                $('#typeLabel').text('I want to invest monthly');
                $('.period-label').text("For a period of");
                $('#first-label').text('Total Invested');
                $('#second-label').text('Gains');
                $('#third-label').text('Future value');
                $('.pie-about').addClass('hide');
                $('.bar-about').removeClass('hide');
                $('.goal-wyg').addClass('hide');
                $('.inv-wyg').removeClass('hide');

                $('.visible-goal').addClass('hide');
                $('.visible-investment').removeClass('hide');

                // windowLoadCallback()
            } else {
                $('.graphic-body').removeClass('bar-graphic-body');
                /*if (window.outerWidth > 991) {
                    $('.chart-box').css('height', "65%");
                }*/

                $(domElem.amountElem).val("10 Lacs"),
                $(domElem.amountElem).attr('data-value', "10,00,000"),
                $(domElem.amountElem).attr('data-max', "1000000000"),
                $(domElem.amountElem).attr('maxlength', "12")
                $(rangeELem).attr('max', '10000000');
                $(rangeELem).val('1000000');
                // $('.amount-form-group .calci-amount').text(capitalizeFirstLetter(valueInWords(1000000)) + " only")
                $('.calci-amount').removeClass('error-msg');
                $('.calci-input-ctrl').removeClass('error-in');
                outputContainer.classList.remove("overlay");

                $('#typeLabel').text('I want to save');
                $('.period-label').text("In a period of");
                $('#first-label').text('Invest monthly');

                $('#second-label').text('Interest earned');
                $('#third-label').text('Goal amount');
                $('.bar-about').addClass('hide');
                $('.pie-about').removeClass('hide');
                $('.inv-wyg').addClass('hide');
                $('.goal-wyg').removeClass('hide');

                $('.visible-investment').addClass('hide');
                $('.visible-goal').removeClass('hide');
            }
            updateSliderEffect(rangeELem);
            reset();
            updateOutput(type);
        });

        $('#amount_yr_toggle').click(function(e) {
            console.log("E", e.target.innerText)
            if (this.previous) {
                this.checked = false;
            }
            this.previous = this.checked;
            if (this.checked) {
                principal = parseInt(domElem.amountElem.dataset.value.replace(/[^0-9]/g, ''));
                additionalYear = e.target.innerText.replace(/[^0-9]/g, "");
                additionalAmount = 0;
                isAdditionalAmount = false;
                $('.amount-values li').removeClass('active');
                $(".year-values li").first().addClass("active");
                $('.tenure-label').addClass('active');
                $('.amount-label').removeClass('active');
                document.querySelector(".year-values").classList.remove("hide");
                document.querySelector(".amount-values").classList.add("hide");
            } else {
                tenure = domElem.TimePeriod.value;
                additionalYear = 0;
                additionalAmount = e.target.innerText.replace(/[^0-9]/g, "");
                isAdditionalAmount = true;
                $('.year-values li').removeClass('active');
                $(".amount-values li").first().addClass("active");
                $('.tenure-label').removeClass('active');
                $('.amount-label').addClass('active');
                document.querySelector(".year-values").classList.add("hide");
                document.querySelector(".amount-values").classList.remove("hide");
            }
            webengageCustomEvent("sa calculator sip amount tenure toggle", {
                SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                Platform: (isMobileDevice() ? 'M web' : 'Web'),
                Toggle: this.checked ? 'Amount' :'Tenure'
            });
            updateOutput();
        });

        $('.calci-radio-btn-inflation').click(function(e) {
            if (this.previous) {
                this.checked = false;
            }
            this.previous = this.checked;
            if (this.checked) {

                isInflation = true;
                document.querySelector(".inflation-box").classList.remove("hide");
            } else {
                isInflation = false;
                document.querySelector(".inflation-box").classList.add("hide");

            }
            webengageCustomEvent("sa calculator sip inflation toggle", {
                SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                Platform: (isMobileDevice() ? 'M web' : 'Web'),
                Toggle: this.checked ? 'On' :'Off'
            });
            updateOutput();
        });

        setTimeout(()=>{
            $(".cal-table tr td:first-child a").click((e)=>{
                webengageCustomEvent("sa calculator sip top funds table", {
                    SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                    Platform: (isMobileDevice() ? 'M web' : 'Web'),
                    Fund: e.target.innerText
                });
            });
            $(".cal-table tr td:last-child span").click((e)=>{
                console.log($(e.target).attr('data-name'))
                webengageCustomEvent("sa calculator sip top funds table", {
                    SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                    Platform: (isMobileDevice() ? 'M web' : 'Web'),
                    Fund: $(e.target).attr('data-name')
                });
            });
        },3000)
       
    } //close windowLoadCallback

    function generateAmountLabels() {
        try {
            principal = parseInt(domElem.amountElem.dataset.value.replace(/[^0-9]/g, ''));

            let ul = document.querySelector(' .amount-values');
            ul.innerHTML = '';
            let principalAmt = principal;
            let firstElement = document.createElement('li');
            firstElement.setAttribute('data-value', principalAmt);
            firstElement.innerText = 'â‚¹' + (principalAmt > 99999 ? convertToLacsAndCrores(principalAmt) : kFormatter(principalAmt));
            firstElement.classList.add('active');
            ul.appendChild(firstElement);
            for (i = 0; i < 3; i++) {
                principalAmt = principalAmt + principal;

                let item = document.createElement('li');
                item.setAttribute('data-value', principalAmt);
                let displayAmt = (principalAmt > 99999 ? convertToLacsAndCrores(principalAmt) : kFormatter(principalAmt));
                if (principalAmt > 99999 && window.outerWidth < 991) {
                    displayAmt = ((displayAmt.replace(/acs/g, '')).replace(/rs/g, '')).replace(/ac/g, '')
                }
                item.innerHTML = 'â‚¹' + displayAmt
                ul.appendChild(item);
            }
            bindClickEventToLi();
        } catch (error) {
            console.log("Error in generateAmountLabels", error);
        }
    }

    function generateYearLabels() {
        let tenureVAL = parseInt(domElem.TimePeriod.value);
        let ul = document.querySelector('.year-values');
        ul.innerHTML = '';

        let firstElement = document.createElement('li');
        firstElement.innerText = tenureVAL + 'Yr';
        firstElement.classList.add('active');
        ul.appendChild(firstElement);
        let incValue = 1;
        if (parseInt(domElem.TimePeriod.value) >= 5) {
            incValue = 2;
        }

        for (i = 0; i < 3; i++) {
            tenureVAL = tenureVAL + incValue;

            let item = document.createElement('li');
            item.innerText = tenureVAL + 'Yr';
            ul.appendChild(item);
        }
        bindClickEventToLi();
    }

    function getGraphLabels() {
        var e = parseInt(domElem.TimePeriod.value),
            t = +domElem.TimePeriod.value,
            a = [];
        if (e >= 6) {
            for (var r = e % 2 == 0 ? 0 : 1; r <= e; r += 2)
                if (r != 0) a.push(r + "Y");
            t != e && a.push(t + "Y")
        } else if (e) {
            for (r = 0; r <= e; r += 1)
                if (r != 0) a.push(r + "Y");
            t != e && a.push(t + "Y")
        } else {
            for (var o = parseInt(12 * domElem.TimePeriod.value), n = 0; n <= o; n += 3)
                n ? a.push(n + " mo") : a.push(n);
            o % 3 != 0 && a.push(o + " mo")
        }
        return a
    }

    function updateOutput(e) {
        try {
            if (type == 'investmentDetails') {
                allInputvalid() && (compoundAmount = calculateMaturityAmount(),
                    compoundInterest = (compoundAmount - (principal * tenure * 12)).toFixed(),
                    domElem.invesdtedAmount.innerText = convertToLacsAndCrores((principal * tenure * 12)),
                    DrawChart(),
                    "function" == typeof animateOutput ? (domElem.InterestGain.setAttribute("data-value", compoundInterest),
                        domElem.InterestGain.classList.add("count"),
                        domElem.maturityAmount.setAttribute("data-value", compoundAmount),
                        domElem.maturityAmount.classList.add("count"),
                        animateOutput(100)) : (domElem.InterestGain.innerText = convertToLacsAndCrores(compoundInterest),
                        domElem.maturityAmount.innerText = convertToLacsAndCrores(compoundAmount)));


            } else {
                let monthlyAmount = calculateGoalInvestmentAmount();
                mainMonthlyAmount = monthlyAmount; //below used
                // console.log("monthlyAmount", monthlyAmount);
                let totalInvested = monthlyAmount * 12 * tenure;
                // console.log("totalInvested", totalInvested);
                allInputvalid() && (compoundInterest = (totalInvested - principal).toFixed(),
                    domElem.invesdtedAmount.innerText = convertToLacsAndCrores(monthlyAmount), //totalInvested
                    DrawChart(),
                    "function" == typeof animateOutput ? (domElem.InterestGain.setAttribute("data-value", compoundInterest),
                        domElem.InterestGain.classList.add("count"),
                        domElem.maturityAmount.setAttribute("data-value", principal), //monthlyAmount
                        domElem.maturityAmount.classList.add("count"),
                        animateOutput(100)) : (domElem.InterestGain.innerText = convertToLacsAndCrores(compoundInterest),
                        domElem.maturityAmount.innerText = convertToLacsAndCrores(principal))) //monthlyAmount
            }
        } catch (error) {
            console.log("ERROR IN UPDATE", error)
        }
    }

    // document.querySelector("input[name='interest']").addEventListener("input", (function (e) {
    //     //strategyTrigger(e.target.value);
    //     var t = e.target.value.replace(/[^0-9.]/g, "");
    //     console.log("t", t)
    //     if (t) {
    //         var a = (t + "").split(".")[1],
    //             r = (t + "").split(".")[0]; +
    //                 r[0] < 2 && r.length > 2 ? r = r.substring(0, 2) : +r[0] >= 3 && r.length > 1 && (r = r.substring(0, 1));
    //                 if(t + "".indexOf(".") > 0 ){
    //                     t = +(r + (a ? "." + a : ".0"));
    //                     a[0] = '0';
    //                 } else {
    //                     t = +r;
    //                 }
    //                 value = a ? +a[1] ? t.toFixed(2) : t.toFixed(1) : t,
    //                 e.target.value = value;
    //                 // domElem.percentageProp.style.left = 10 + 10 * value.length + "px",
    //                 updateOutput()
    //     } else
    //         showError(e.target, 'Please enter interest rate');
    //         outputContainer.classList.add("overlay"),
    //         calculateBtn.classList.add("cta-primary")
    // }));    

    function commaSeprated(e) {
        let t = (e = e.toString()).substring(e.length - 3),
            n = e.substring(0, e.length - 3);
        return "" != n && (t = "," + t), n.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + t;
    }

    function commaSeparatorCurrency(e) {
        if ((e && (e = (e += "").replace(/,/g, "")), +e)) {
            var t = (e += "").split(".")[1],
                n = (i = e.split(".")[0]).substring(i.length - 3),
                a = i.substring(0, i.length - 3);
            "" != a && (n = "," + n);
            var i = a.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + n;
            return null == t ? i : i + "." + t;
        }
        return e;
    }

    function kFormatter(num) {
        return Math.abs(num) >= 10000 ? Math.sign(num) * ((Math.abs(num) / 1000).toFixed(1)) + 'k' : Math.sign(num) * Math.abs(num)
    }

    // e is targetAmount
    // t is roi,
    // n is tenure;
    function getMonthlyAmount(e, t, n) {
        (e = +e.replace(/,/g, "")), (t = +t.replace(/,/g, ""));
        let a = 12 * (n = +n.replace(/,/g, ""));
        var r,
            l = 0;
        for (i = 0; i < a; i++) l += Math.pow(1 + t / 1200, a - i);
        return (r = Math.round(e / l));
    }

    function commaSeprated(e) {
        let t = (e = e.toString()).substring(e.length - 3),
            n = e.substring(0, e.length - 3);
        return "" != n && (t = "," + t), n.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + t;
    }

    function currencyFormat(e) {
        return e >= 1e3 && e < 99999 ?
            ((e = (e / 1e3).toFixed(2) + " K"), (formatedValue = e)) :
            e >= 1e5 && e < 9999999 ?
            ((e = (e / 1e5).toFixed(2) + " lacs"), (formatedValue = e)) :
            e >= 1e7 && e <= 1e8 ?
            ((e = (e / 1e7).toFixed(2) + " cr"), (formatedValue = e)) :
            e >= 1e8 && e < 9999999999 ?
            ((e = (e / 1e7).toFixed(2) + " cr"), (formatedValue = e)) :
            (formatedValue = commaSeprated(e));
    }

    function calculateGoalInvestmentAmount() {
        // console.log("isInflation", isInflation)
        principal = parseInt(domElem.amountElem.dataset.value.replace(/[^0-9]/g, ''));
        if (isInflation) {
            let inflationValue = inflationRate / 100;
            // The formula for inflation adjusted goal value = present goal * (1+inflation%)^10. So here
            // 50*(1+0.04)^10 = 74,012 so it's lumpsum investment value required is 34,282 & interest=39730
            // console.log("-------",50000 * Math.pow((1 + 0.04),periods));
            // console.log("PRINCIPLE BEFOR", principal)
            value = Math.round(principal * Math.pow((1 + inflationValue), parseInt(tenure)))
            principal = value;
            // console.log("principal 1", principal)
        }
        // console.log("principal 2", principal)

        var e = principal,
            t = interest,
            n = tenure;

        (e = +e), (t = +t);
        let a = 12 * (n = +n);
        var r,
            l = 0;
        for (i = 0; i < a; i++) l += Math.pow(1 + t / 1200, a - i);
        //console.log('Math.round(e / l)', Math.round(e / l))
        //return (r = Math.round(e / l));
        return (r = (e / l).toFixed(2));
    }

    function calculateMaturityAmount(e) {
        // console.log("INTEREST 1", interest)


        var investment = principal;
        var annualRate = interest;
        var monthlyRate = annualRate / 12 / 100;
        var years = tenure;
        var months = years * 12;
        let amount = 0;

        $('.extraInvAmt').html(convertToLacsAndCrores(principal));

        if (interest != 0) {
            amount = investment * (Math.pow(1 + monthlyRate, months) - 1) * (1 + monthlyRate) / monthlyRate;
        } else {
            amount = months * investment;
        }
        let extraInvFuture = ((investment * 2) * (Math.pow(1 + monthlyRate, months) - 1) * (1 + monthlyRate) / monthlyRate);

        $('.extraInvFuture').html(convertToLacsAndCrores(Math.ceil(extraInvFuture) - amount));

        return amount;
    }

    function bindClickEventToLi() {
        document.querySelectorAll(".percent-inv-values li").forEach((function(e) {
            e.addEventListener("click", (function(e) {
                // console.log(e.target.getAttribute('data-value'))
                let innertTextVal = e.target.innerText.replace(/[^0-9]/g, "");
                let val = e.target.getAttribute('data-value') ? e.target.getAttribute('data-value').replace(/[^0-9]/g, "") : innertTextVal;
                if (isAdditionalAmount) {
                    principal = parseInt(val);
                    webengageCustomEvent("sa calculator sip amount toggle val", {
                        SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                        Platform: (isMobileDevice() ? 'M web' : 'Web'),
                        Amount: parseInt(val)
                    });
                } else {
                    tenure = parseInt(innertTextVal);
                    webengageCustomEvent("sa calculator sip tenure toggle val", {
                        SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                        Platform: (isMobileDevice() ? 'M web' : 'Web'),
                        Tenure: parseInt(innertTextVal)
                    });
                }
                document.querySelector(".percent-inv-values li.active").classList.remove("active");
                e.target.classList.add("active");

                
                updateOutput();
            }));
        }))
    }
    bindClickEventToLi()


    document.querySelectorAll(".inflation-values li").forEach((function(e) {
        e.addEventListener("click", (function(e) {
            inflationRate = e.target.innerText.replace(/[^0-9]/g, "");
            document.querySelector(".inflation-values li.active").classList.remove("active");
            e.target.classList.add("active");
            webengageCustomEvent("sa calculator sip inflation", {
                SCREEN_NAME: `SIP Calculator - ${calculationType}`,
                Platform: (isMobileDevice() ? 'M web' : 'Web'),
                InflationPercentage: inflationRate
            });
            updateOutput();
        }));
    }))

    document.querySelectorAll(".interest-tenure li").forEach((function(e) {
        e.addEventListener("click", (function(e) {
            selectedPeriod != e.target.innerText && (selectedPeriod = e.target.innerText,
                document.querySelector(".interest-tenure li.active").classList.remove("active"),
                e.currentTarget.classList.add("active"),
                compoundInterval = "Yearly" == selectedPeriod ? 1 : "Quarterly" == selectedPeriod ? 4 : 12,
                updateOutput(!0),
                customGaEvents("Calc-widget_Calculator Page", "Click - Toggle", e.target.innerText + " - " + pageName))
        }))
    }));

    // document.querySelectorAll("input[type='number'], input[name='interest']").forEach((function(e) {
    //     e.addEventListener("blur", (function(t) {
    //         console.log("blur", e.value)
    //         "interest" == e.name ? e.value || (e.value = 0, interest = 0,
    //                 domElem.percentageProp.style.left = 10 + 10 * t.target.value.length + "px") : "period" == e.name && (e.value ? +e.value <= 0 && showError(e, "Please enter valid period") : showError(e, "This field is required")),
    //             updateOutput()
    //     }))
    // }))

    function updateInput(){
        reset();
    }

    function reset() {
        additionalAmount = 0;
        additionalYear = 0;
        $('.calci-amount').removeClass('error-msg');
        principal = +domElem.amountElem.dataset.value.replace(/[^0-9]/g, "");
        tenure = domElem.TimePeriod.value;
        interest = domElem.interestElem.value;
        $('#show_earn_more_parent').removeClass('hidden');
        $('#earn_more').addClass('hidden');
        $(".amount-values li").removeClass("active");
        $(".amount-values li").first().addClass("active");
        updateOutput()
    }
    document.querySelector("#reset").addEventListener("click", (function(e) {
        webengageCustomEvent("sa calculator sip reset toggle", {
            SCREEN_NAME: `SIP Calculator - ${calculationType}`,
            Platform: (isMobileDevice() ? 'M web' : 'Web'),
        });
        reset();
    }));


    function DrawChart() {
        if (type == 'investmentDetails') {
            updateChart()
        } else {
            updateGoalChart();
        }
    }

    function updateGoalChart() {
        var e;
        //outputContainer && (outputContainer.classList.remove("overlay"),
                // calculateBtn.classList.remove("cta-primary"),
            chart && chart.destroy && chart.destroy();

        let totalInvested = mainMonthlyAmount * 12 * tenure;
        var interestEarn = principal - totalInvested;

        var t = document.getElementById("myChart").getContext("2d");
        chart = new Chart(t, {
            type: "doughnut",
            data: {
                labels: ["Interest earned", "Total Invested"],
                datasets: [{
                    backgroundColor: ["#6880C8", "#DDDDDD"],
                    data: [interestEarn.toFixed(2), totalInvested.toFixed(2)],
                    hoverBackgroundColor: ["#6880C8", "#DDDDDD"],
                    weight: .5
                }]
            },
            options: {
                segmentShowStroke: !1,
                aspectRatio: 2,
                responsive: !0,
                legend: {
                    display: !1,
                    position: "bottom",
                    labels: {
                        boxWidth: 6
                    },
                    usePointStyle: !0
                }
            }
        });
        domElem.rightLabel.classList.remove("hide"),
            domElem.leftLabel.classList.remove("hide");

    }

    function updateChart() {
        var e;
        domElem.rightLabel.classList.add("hide"),
            domElem.leftLabel.classList.add("hide");

        // outputContainer && (outputContainer.classList.remove("overlay"),
                // calculateBtn.classList.remove("cta-primary"),
            chart && chart.destroy && chart.destroy();
        let genLabels = [];
        for (let index = 0; index < tenure; index++) {
            genLabels.push((index + 1) + 'Y')

        }
        let labels = genLabels; //getGraphLabels() || ['1Y', '2Y', '3Y', '4Y', '5Y']; //[1,2, 3, 4, 5];
        let n = 1;
        let interestArray = [];
        let principalArray = []
        let r = parseFloat(interest) / 100;
        for (let tenr of labels) {
            tenr = tenr.replace(/[^0-9.]/g, "");
            let totalAmt = principal * tenr * 12;
            principalArray.push(totalAmt);

            var monthlyRate = interest / 12 / 100;
            var months = tenr * 12;
            let amount = 0;
            amount = principal * (Math.pow(1 + monthlyRate, months) - 1) * (1 + monthlyRate) / monthlyRate;
            interestArray.push((amount - totalAmt).toFixed());
        }
        //NEW IMPL
        var t = document.getElementById("myChart").getContext("2d")
        var ci = compoundAmount;
        ci && (e = (e = Math.round(ci / 3) + "")[0] * Math.pow(10, e.length - 1));

        const data = {
            labels: genLabels, //getGraphLabels() || ['1Y', '2Y', '3Y', '4Y', '5Y'],
            datasets: [{
                    label: 'Total invested',
                    data: principalArray,
                    backgroundColor: '#DDDDDD'
                },
                {
                    label: 'Gains',
                    data: interestArray,
                    backgroundColor: '#6880C8'
                }
            ]
        };

        const config = {
            type: 'bar',
            data: data,
            options: {
                
                legend: {
                    display: false
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'Chart.js Bar Chart - Stacked'
                    },
                },
                tooltips: {
                    enabled: true,
                    mode: 'single',
                    callbacks: {
                        label: function(tooltipItems, data) {
                            let vl = tooltipItems.xLabel.replace(/[^0-9]/g, "");
                            let lbl = parseInt(tooltipItems.yLabel) == (principal * vl * 12) ? 'Total invested ' : 'Gains: ';
                            return lbl + 'â‚¹' + commaSeparatorCurrency(tooltipItems.yLabel);
                        }
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                layout: {
                    padding: {
                       right: 35,
                        top: 30
                    }
                },
                scales: {
                    xAxes: [{
                        stacked: true,
                        gridLines: {
                            display: false,
                        },
                        
                    }],
                    yAxes: [{
                        stacked: true,
                        gridLines: {
                            display: true,
                            drawBorder: false,
                            zeroLineColor:"#DDDDDD"
                        },
                        ticks: {
                            stepSize: e || 5e3,
                            callback: function(e, t, a) {
                                return convertToLacsAndCrores(e, !0)
                            }
                        }
                    }]
                },
                animation: {
                    // duration: 1,
                    onComplete: function() {
                        var chartInstance = this.chart,
                            ctx = chartInstance.ctx;

                        //ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'bottom';
                        var dcount = this.data.datasets.length;
                        this.data.datasets.forEach(function(dataset, i) {
                            var meta = chartInstance.controller.getDatasetMeta(i);
                            if (dcount == i + 1) {
                                meta.data.forEach(function(bar, index) {
                                    if (dataset.data[index] > 0 && meta.data.length == index + 1) {
                                        // var data = dataset.data[index];
                                        var data = 'â‚¹' + convertToLacsAndCrores(Math.ceil(calculateMaturityAmount()));
                                        ctx.font = "bold 14px 'proxima-nova-bold'";
                                        ctx.fillStyle = "#4c4c4c";
                                        data = (data.replace(/acs/g, '')).replace(/Crs/g, 'Cr');
                                        ctx.fillText(data, bar._model.x, bar._model.y - 10);
                                    }
                                });
                            }
                        });
                    }
                }
            }
        };
        chart = new Chart(t, config);
    }