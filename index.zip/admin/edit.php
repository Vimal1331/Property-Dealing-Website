<?php
include_once("db_connection.php");

$displayBackbutton = 0;


if (isset($_GET['id'])) {
    $detailId = $_GET['id'];

    // Fetch details
    $sql = "SELECT * FROM details WHERE id = $detailId";
    $result = mysqli_query($connection, $sql);

    if ($row = mysqli_fetch_assoc($result)) {
        $title = $row['title'];
        $remark = $row['remark'];
        $status = $row['status'];
        ?>



<?php include('header.php') ?>



<div class="app-main__outer">
    <div class="app-main__inner">
       
    
        <div class="row" >

            <div class="col-md-12 col-lg-12">
                <div class="mb-3 card">
                    <div class="card-header-tab card-header">
                        <div class="card-header-title">
                            <i class="header-icon lnr-rocket icon-gradient bg-tempting-azure"> </i>
                            EDIT PROPERTY
                        </div>
                        <div class="btn-actions-pane-right">
                            <div class="nav">
                               
                            </div>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade active show" id="tab-eg-55">

                            <div class="pt-2 card-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <form action="<?php echo $_SERVER['PHP_SELF'] . "?id=$detailId"; ?>" method="post">
                                            <div class="mb-3">
                                                <label for="title" class="form-label">Title:</label>
                                                <input type="text" name="title" class="form-control"  value="<?php echo $title; ?>"  required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="status" class="form-label">Status:</label>
                                                <select name="status" class="form-select form-control" required>
                                                    <!-- <option value="Active">Sale</option>
                                                    <option value="Inactive">Solde</option> -->

                                                    <option value="Active" <?php echo ($status == 'Active') ? 'selected' : ''; ?>>Sale</option>
                        <option value="Inactive" <?php echo ($status == 'Inactive') ? 'selected' : ''; ?>>Solde</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="remark" class="form-label">Remark:</label>
                                                <!-- <textarea name="remark" class="form-control"></textarea> -->



                                                <!DOCTYPE html>
                                                <html lang="en">

                                                <head>
                                                    <meta charset="UTF-8">
                                                </head>

                                                <body>
                                                    <style>
                                                    #container {
                                                        width: 1000px;
                                                        margin: 20px auto;
                                                    }

                                                    .ck-editor__editable[role="textbox"] {
                                                        /* editing area */
                                                        min-height: 200px;
                                                    }

                                                    .ck-content .image {
                                                        /* block images */
                                                        max-width: 80%;
                                                        margin: 20px auto;
                                                    }
                                                    </style>
                                                    <div id="container">
                                                        <textarea id="editor" name="remark"><?php echo $remark; ?></textarea>
            </textarea>
                                                    </div>
                                                    <!--
            The "super-build" of CKEditor&nbsp;5 served via CDN contains a large set of plugins and multiple editor types.
            See https://ckeditor.com/docs/ckeditor5/latest/installation/getting-started/quick-start.html#running-a-full-featured-editor-from-cdn
        -->
                                                    <script
                                                        src="https://cdn.ckeditor.com/ckeditor5/40.1.0/super-build/ckeditor.js">
                                                    </script>
                                                    <!--
            Uncomment to load the Spanish translation
            <script src="https://cdn.ckeditor.com/ckeditor5/40.1.0/super-build/translations/es.js"></script>
        -->
                                                    <script>
                                                    // This sample still does not showcase all CKEditor&nbsp;5 features (!)
                                                    // Visit https://ckeditor.com/docs/ckeditor5/latest/features/index.html to browse all the features.
                                                    CKEDITOR.ClassicEditor.create(document.getElementById("editor"), {
                                                        // https://ckeditor.com/docs/ckeditor5/latest/features/toolbar/toolbar.html#extended-toolbar-configuration-format
                                                        toolbar: {
                                                            items: [
                                                                'exportPDF', 'exportWord', '|',
                                                                'findAndReplace', 'selectAll', '|',
                                                                'heading', '|',
                                                                'bold', 'italic', 'strikethrough',
                                                                'underline', 'code', 'subscript',
                                                                'superscript', 'removeFormat', '|',
                                                                'bulletedList', 'numberedList', 'todoList',
                                                                '|',
                                                                'outdent', 'indent', '|',
                                                                'undo', 'redo',
                                                                '-',
                                                                'fontSize', 'fontFamily', 'fontColor',
                                                                'fontBackgroundColor', 'highlight', '|',
                                                                'alignment', '|',
                                                                'link', 'insertImage', 'blockQuote',
                                                                'insertTable', 'mediaEmbed', 'codeBlock',
                                                                'htmlEmbed', '|',
                                                                'specialCharacters', 'horizontalLine',
                                                                'pageBreak', '|',
                                                                'textPartLanguage', '|',
                                                                'sourceEditing'
                                                            ],
                                                            shouldNotGroupWhenFull: true
                                                        },
                                                        // Changing the language of the interface requires loading the language file using the <script> tag.
                                                        // language: 'es',
                                                        list: {
                                                            properties: {
                                                                styles: true,
                                                                startIndex: true,
                                                                reversed: true
                                                            }
                                                        },
                                                        // https://ckeditor.com/docs/ckeditor5/latest/features/headings.html#configuration
                                                        heading: {
                                                            options: [{
                                                                    model: 'paragraph',
                                                                    title: 'Paragraph',
                                                                    class: 'ck-heading_paragraph'
                                                                },
                                                                {
                                                                    model: 'heading1',
                                                                    view: 'h1',
                                                                    title: 'Heading 1',
                                                                    class: 'ck-heading_heading1'
                                                                },
                                                                {
                                                                    model: 'heading2',
                                                                    view: 'h2',
                                                                    title: 'Heading 2',
                                                                    class: 'ck-heading_heading2'
                                                                },
                                                                {
                                                                    model: 'heading3',
                                                                    view: 'h3',
                                                                    title: 'Heading 3',
                                                                    class: 'ck-heading_heading3'
                                                                },
                                                                {
                                                                    model: 'heading4',
                                                                    view: 'h4',
                                                                    title: 'Heading 4',
                                                                    class: 'ck-heading_heading4'
                                                                },
                                                                {
                                                                    model: 'heading5',
                                                                    view: 'h5',
                                                                    title: 'Heading 5',
                                                                    class: 'ck-heading_heading5'
                                                                },
                                                                {
                                                                    model: 'heading6',
                                                                    view: 'h6',
                                                                    title: 'Heading 6',
                                                                    class: 'ck-heading_heading6'
                                                                }
                                                            ]
                                                        },
                                                        // https://ckeditor.com/docs/ckeditor5/latest/features/editor-placeholder.html#using-the-editor-configuration
                                                        placeholder: 'Welcome to CKEditor&nbsp;5!',
                                                        // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-family-feature
                                                        fontFamily: {
                                                            options: [
                                                                'default',
                                                                'Arial, Helvetica, sans-serif',
                                                                'Courier New, Courier, monospace',
                                                                'Georgia, serif',
                                                                'Lucida Sans Unicode, Lucida Grande, sans-serif',
                                                                'Tahoma, Geneva, sans-serif',
                                                                'Times New Roman, Times, serif',
                                                                'Trebuchet MS, Helvetica, sans-serif',
                                                                'Verdana, Geneva, sans-serif'
                                                            ],
                                                            supportAllValues: true
                                                        },
                                                        // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-size-feature
                                                        fontSize: {
                                                            options: [10, 12, 14, 'default', 18, 20, 22],
                                                            supportAllValues: true
                                                        },
                                                        // Be careful with the setting below. It instructs CKEditor to accept ALL HTML markup.
                                                        // https://ckeditor.com/docs/ckeditor5/latest/features/general-html-support.html#enabling-all-html-features
                                                        htmlSupport: {
                                                            allow: [{
                                                                name: /.*/,
                                                                attributes: true,
                                                                classes: true,
                                                                styles: true
                                                            }]
                                                        },
                                                        // Be careful with enabling previews
                                                        // https://ckeditor.com/docs/ckeditor5/latest/features/html-embed.html#content-previews
                                                        htmlEmbed: {
                                                            showPreviews: true
                                                        },
                                                        // https://ckeditor.com/docs/ckeditor5/latest/features/link.html#custom-link-attributes-decorators
                                                        link: {
                                                            decorators: {
                                                                addTargetToExternalLinks: true,
                                                                defaultProtocol: 'https://',
                                                                toggleDownloadable: {
                                                                    mode: 'manual',
                                                                    label: 'Downloadable',
                                                                    attributes: {
                                                                        download: 'file'
                                                                    }
                                                                }
                                                            }
                                                        },
                                                        // https://ckeditor.com/docs/ckeditor5/latest/features/mentions.html#configuration
                                                        mention: {
                                                            feeds: [{
                                                                marker: '@',
                                                                feed: [
                                                                    '@apple', '@bears', '@brownie',
                                                                    '@cake', '@cake', '@candy',
                                                                    '@canes', '@chocolate',
                                                                    '@cookie', '@cotton', '@cream',
                                                                    '@cupcake', '@danish', '@donut',
                                                                    '@dragée', '@fruitcake',
                                                                    '@gingerbread', '@gummi',
                                                                    '@ice', '@jelly-o',
                                                                    '@liquorice', '@macaroon',
                                                                    '@marzipan', '@oat', '@pie',
                                                                    '@plum', '@pudding', '@sesame',
                                                                    '@snaps', '@soufflé',
                                                                    '@sugar', '@sweet', '@topping',
                                                                    '@wafer'
                                                                ],
                                                                minimumCharacters: 1
                                                            }]
                                                        },
                                                        // The "super-build" contains more premium features that require additional configuration, disable them below.
                                                        // Do not turn them on unless you read the documentation and know how to configure them and setup the editor.
                                                        removePlugins: [
                                                            // These two are commercial, but you can try them out without registering to a trial.
                                                            // 'ExportPdf',
                                                            // 'ExportWord',
                                                            'AIAssistant',
                                                            'CKBox',
                                                            'CKFinder',
                                                            'EasyImage',
                                                            // This sample uses the Base64UploadAdapter to handle image uploads as it requires no configuration.
                                                            // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/base64-upload-adapter.html
                                                            // Storing images as Base64 is usually a very bad idea.
                                                            // Replace it on production website with other solutions:
                                                            // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/image-upload.html
                                                            // 'Base64UploadAdapter',
                                                            'RealTimeCollaborativeComments',
                                                            'RealTimeCollaborativeTrackChanges',
                                                            'RealTimeCollaborativeRevisionHistory',
                                                            'PresenceList',
                                                            'Comments',
                                                            'TrackChanges',
                                                            'TrackChangesData',
                                                            'RevisionHistory',
                                                            'Pagination',
                                                            'WProofreader',
                                                            // Careful, with the Mathtype plugin CKEditor will not load when loading this sample
                                                            // from a local file system (file://) - load this site via HTTP server if you enable MathType.
                                                            'MathType',
                                                            // The following features are part of the Productivity Pack and require additional license.
                                                            'SlashCommand',
                                                            'Template',
                                                            'DocumentOutline',
                                                            'FormatPainter',
                                                            'TableOfContents',
                                                            'PasteFromOfficeEnhanced'
                                                        ]
                                                    });
                                                    </script>
                                                </body>

                                                </html>



                                            </div>

                                            <div class="mb-3">
                                                <label for="images" class="form-label">Select Images:</label>
                                                <input type="file" name="images[]" class="form-control" accept="image/*"
                                                    multiple >
                                            </div>

                                            <button type="submit" class="btn btn-primary">Upload</button>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       

    </div>

</div>

<?php 
if($displayBackbutton == 1){
    ?>

<div class="app-main__outer">
    <div class="app-main__inner">
    <div class="alert alert-success" role="alert">
    Details updated successfully.
</div>
</div>


</div>
<?php 
}

?>



<?php include('footer.php') ?>





<?php
    } else {
        echo "Details not found.";
        exit();
    }
} else {
    echo "Invalid request.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get updated details
$title = $_POST["title"];
$remark = $_POST["remark"];
$status = $_POST["status"];

// Update details
$updateSql = "UPDATE details SET title='$title', remark='$remark', status='$status' WHERE id=$detailId";
$updateResult = mysqli_query($connection, $updateSql);

// Check if the details were updated successfully
if (!$updateResult) {
    echo "Error updating details: " . mysqli_error($connection);
    exit;
}

$targetDirectory = "uploads/";

// Check if files were chosen during edit time
if (!empty(array_filter($_FILES['images']['name']))) {
    // Remove existing images associated with the detail_id
    $deleteSql = "DELETE FROM images WHERE detail_id = '$detailId'";
    $deleteResult = mysqli_query($connection, $deleteSql);

    if (!$deleteResult) {
        echo "Error deleting existing images: " . mysqli_error($connection);
        exit;
    }

    // Upload and insert newly chosen images
    foreach ($_FILES["images"]["tmp_name"] as $key => $tmp_name) {
        $originalFileName = $_FILES["images"]["name"][$key];
        $fileExtension = pathinfo($originalFileName, PATHINFO_EXTENSION);

        // Create a unique name using the current date, time, and a random number
        $newFileName = date("YmdHis") . "_" . mt_rand(1000, 9999) . "." . $fileExtension;

        $targetFile = $targetDirectory . $newFileName;

        // Check if the file already exists and generate a new name if needed
        while (file_exists($targetFile)) {
            $newFileName = date("YmdHis") . "_" . mt_rand(1000, 9999) . "." . $fileExtension;
            $targetFile = $targetDirectory . $newFileName;
        }

        move_uploaded_file($tmp_name, $targetFile);

        // Insert file information into the 'images' table with the corresponding detail_id
        $insertSql = "INSERT INTO images (detail_id, file_name) VALUES ('$detailId', '$targetFile')";
        $insertResult = mysqli_query($connection, $insertSql);

        if (!$insertResult) {
            // Handle the error, log it, or display an appropriate message
            echo "Error inserting into database: " . mysqli_error($connection);
            exit;
        }
    }
} 








    if ($updateResult) {
        // Details updated successfully, show Bootstrap modal
        echo <<<HTML
            <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-success  text-center">
          
                     <h4 class="modal-title text-center text-white" id="successModalLabel" >           <center><strong>Success !</strong>       </center></h4>
               
                            <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button> -->
                        </div>
                        <div class="modal-body text-center">
                          <p class="text-success"> Property Details updated successfully.</p>
<br><br>
                            <a href="property.php" class="btn btn-success">Done</a>
                        </div>
                        <!-- <div class="modal-footer">
                            
                        </div> -->
                    </div>
                </div>
            </div>

            <script>
                var successModal = new bootstrap.Modal(document.getElementById('successModal'));
                successModal.show();
            </script>
              
HTML;
    } else {
        echo "Error updating details: " . mysqli_error($connection);
    }
}

mysqli_close($connection);
?>