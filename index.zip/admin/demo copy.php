<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIP Return Calculator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h1 class="text-center">SIP Return Calculator</h1>

    <div class="mb-3">
        <label for="sipAmount" class="form-label">Monthly SIP Amount: <span id="sipAmountValue">1000</span></label>
        <input type="range" class="form-range" min="500" max="5000" step="100" value="1000" id="sipAmount">
    </div>

    <div class="mb-3">
        <label for="annualReturn" class="form-label">Expected Annual Return (%): <span id="annualReturnValue">1</span></label>
        <input type="range" class="form-range" min="1" max="20" step="1" value="1" id="annualReturn">
    </div>

    <div class="mb-3">
        <label for="years" class="form-label">Number of Years: <span id="yearsValue">1</span></label>
        <input type="range" class="form-range" min="1" max="30" step="1" value="1" id="years">
    </div>

    <button class="btn btn-primary" onclick="calculateSIPReturn()">Calculate SIP Return</button>

    <div class="mt-4">
        <h4>Results:</h4>
        <p>Total Invested Amount: <span id="totalInvested">0.00</span></p>
        <p>Return Amount: <span id="returnAmount">0.00</span></p>
        <p>Total Future Value: <span id="totalFutureValue">0.00</span></p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function calculateSIPReturn() {
        const sipAmount = parseFloat(document.getElementById('sipAmount').value);
        const annualReturn = parseFloat(document.getElementById('annualReturn').value);
        const years = parseInt(document.getElementById('years').value);


        const monthlyRate = annualReturn / 12 / 100;
        const totalMonths = years * 12;

        const futureValue = sipAmount * ((Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate) + annualReturn * 10;

        const totalInvested = sipAmount * totalMonths;
        const returnAmount = futureValue - totalInvested ;

        // returnAmount
        // alert(returnAmount);
        // Display the results
        document.getElementById('totalInvested').innerText = totalInvested.toFixed(2);
        document.getElementById('returnAmount').innerText = returnAmount.toFixed(2);
        document.getElementById('totalFutureValue').innerText = futureValue.toFixed(2);
    }

    // Update range input values dynamically
    document.getElementById('sipAmount').addEventListener('input', function () {
        document.getElementById('sipAmountValue').innerText = this.value;
    });

    document.getElementById('annualReturn').addEventListener('input', function () {
        document.getElementById('annualReturnValue').innerText = this.value;
    });

    document.getElementById('years').addEventListener('input', function () {
        document.getElementById('yearsValue').innerText = this.value;
    });
</script>

</body>
</html>
