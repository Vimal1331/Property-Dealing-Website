<?php
include_once("db_connection.php");

$displayBackbutton = 0;


if (isset($_GET['id'])) {
    $detailId = $_GET['id'];

    // Fetch details
    $sql = "SELECT * FROM details WHERE id = $detailId";
    $result = mysqli_query($connection, $sql);

    if ($row = mysqli_fetch_assoc($result)) {
        $title = $row['title'];
        $remark = $row['remark'];
        $status = $row['status'];
        ?>




























<?php include('header.php') ?>



<div class="app-main__outer">
    <div class="app-main__inner">


        <div class="row">

            <div class="col-md-12 col-lg-12">
                <div class="mb-3 card">
                    <div class="card-header-tab card-header">
                        <div class="card-header-title">
                            <i class="header-icon lnr-rocket icon-gradient bg-tempting-azure"> </i>
                            EDIT PROPERTY
                        </div>
                        <div class="btn-actions-pane-right">
                            <div class="nav">
                                <!-- <a href="javascript:void(0);"
                                                class="border-0 btn-pill btn-wide btn-transition active btn btn-outline-alternate">Tab
                                                1</a>
                                            <a href="javascript:void(0);"
                                                class="ml-1 btn-pill btn-wide border-0 btn-transition  btn btn-outline-alternate second-tab-toggle-alt">Tab
                                                2</a> -->
                            </div>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade active show" id="tab-eg-55">

                            <div class="pt-2 card-body">

                                <div class="row">
                                    <div class="col-md-12">

                                        <p class="card-text"><strong>Title:</strong> <?php echo $title; ?></p>
                                        <p class="card-text"><strong>Remark:</strong> <?php echo $remark; ?></p>
                                        <!-- <p class="card-text"><strong>Status:</strong> <?php echo $detailRow['status']; ?></p>
                    <p class="card-text"><strong>Created At:</strong> <?php echo $detailRow['created_at']; ?></p>
                    <p class="card-text"><strong>Updated At:</strong> <?php echo $detailRow['updated_at']; ?></p> -->

                    <div class="col-lg-8 ">
    <h3 class="text-start">Property Pictures</h3>
</div>
<div class="col-lg-12">
    <div class="row">
        <?php
        $imageSql = "SELECT * FROM images WHERE detail_id = $detailId";
        $imageResult = mysqli_query($connection, $imageSql);

        if (mysqli_num_rows($imageResult) > 0) {
            while ($imageRow = mysqli_fetch_assoc($imageResult)) {
                ?>
                <div class="col-4 mb-3">
                    <img src="<?php echo $imageRow['file_name']; ?>" class="img-fluid" alt="Image">
                </div>
                <?php
            }
        } else {
            echo "<p>No images found for this detail.</p>";
        }
        ?>
    </div>
</div>











                                       
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    </div>

</div>




<?php include('footer.php') ?>





<?php
    } else {
        echo "Details not found.";
        exit();
    }
} else {
    echo "Invalid request.";
    exit();
}

mysqli_close($connection);
?>