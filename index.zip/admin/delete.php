<?php
include_once("db_connection.php");

if (isset($_GET['id'])) {
    $detailId = $_GET['id'];

    // Delete details and associated images
    $deleteSql = "DELETE FROM details WHERE id = $detailId";
    $deleteResult = mysqli_query($connection, $deleteSql);

    if ($deleteResult) {
        // echo "Details and associated images deleted successfully.";
        
        header("Location: property.php");
        exit;
exit;
    } else {
        echo "Error deleting details: " . mysqli_error($connection);
    }
} else {
    echo "Invalid request.";
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Details</title>
</head>
<body>
    <br>
    <a href="property.php">Back to Details List</a>
</body>
</html>
