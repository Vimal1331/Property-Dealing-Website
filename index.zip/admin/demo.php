<?php
include_once("db_connection.php");

if (isset($_GET['id'])) {
    $detailId = $_GET['id'];

    // Fetch details
    $detailSql = "SELECT * FROM details WHERE id = $detailId";
    $detailResult = mysqli_query($connection, $detailSql);

    if ($detailRow = mysqli_fetch_assoc($detailResult)) {
        ?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>View Details</title>
            <!-- Bootstrap CSS -->
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <a href="property.php" class="btn btn-secondary">Back to Details List</a>
        <body class="container mt-5">

            <h2>Details</h2>

            <div class="card">
                <div class="card-body">
                    <p class="card-text"><strong>Title:</strong> <?php echo $detailRow['title']; ?></p>
                    <p class="card-text"><strong>Remark:</strong> <?php echo $detailRow['remark']; ?></p>
                    <p class="card-text"><strong>Status:</strong> <?php echo $detailRow['status']; ?></p>
                    <p class="card-text"><strong>Created At:</strong> <?php echo $detailRow['created_at']; ?></p>
                    <p class="card-text"><strong>Updated At:</strong> <?php echo $detailRow['updated_at']; ?></p>
                </div>
            </div>

            <!-- Fetch associated images -->
            <?php
            $imageSql = "SELECT * FROM images WHERE detail_id = $detailId";
            $imageResult = mysqli_query($connection, $imageSql);

            if (mysqli_num_rows($imageResult) > 0) {
                ?>
                <h3 class="mt-3">Images</h3>
                <div class="row">
                    <?php
                    while ($imageRow = mysqli_fetch_assoc($imageResult)) {
                        ?>
                        <div class="col-md-4">
                            <img src="<?php echo $imageRow['file_name']; ?>" class="img-fluid mb-3" alt="Image">
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <?php
            } else {
                echo "<p class='mt-3'>No images found for this detail.</p>";
            }
            ?>
        
            <!-- Bootstrap JS and Popper.js -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        </body>
        </html>

        <?php
    } else {
        echo "Details not found.";
    }
} else {
    echo "Invalid request.";
}

// Close the connection
mysqli_close($connection);
?>
