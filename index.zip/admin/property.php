<?php
include_once("db_connection.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get detail ID to update
    $detailId = $_POST["detail_id"]; // Assuming you have a hidden input field for detail ID in your form

    // Get updated title and remark from the form
    $title = $_POST["title"];
    $remark = $_POST["remark"];

    // Update details in the 'details' table
    $updateSql = "UPDATE details SET title='$title', remark='$remark' WHERE id=$detailId";
    $updateResult = mysqli_query($connection, $updateSql);

    // Check if details were updated successfully
    if (!$updateResult) {
        echo "Error updating details: " . mysqli_error($connection);
        exit;
    }

    // Upload and save new images
    $targetDirectory = "uploads/";

    foreach ($_FILES["images"]["tmp_name"] as $key => $tmp_name) {
        $originalFileName = $_FILES["images"]["name"][$key];
        $fileExtension = pathinfo($originalFileName, PATHINFO_EXTENSION);

        // Create a unique name using current date, time, and a random number
        $newFileName = date("YmdHis") . "_" . mt_rand(1000, 9999) . "." . $fileExtension;

        $targetFile = $targetDirectory . $newFileName;

        // Check if the file already exists, and generate a new name if needed
        while (file_exists($targetFile)) {
            $newFileName = date("YmdHis") . "_" . mt_rand(1000, 9999) . "." . $fileExtension;
            $targetFile = $targetDirectory . $newFileName;
        }

        move_uploaded_file($tmp_name, $targetFile);

        // Insert file information into the 'images' table with the corresponding detail_id
        $insertSql = "INSERT INTO images (detail_id, file_name) VALUES ('$detailId', '$targetFile')";
        $insertResult = mysqli_query($connection, $insertSql);

        if (!$insertResult) {
            // Handle the error, log it, or display an appropriate message
            echo "Error inserting into database: " . mysqli_error($connection);
            exit;
        }
    }

    // If the code reaches here, both details and images were updated successfully
    echo "Details and images updated successfully.";
}




$activeCountQuery = "SELECT COUNT(*) as Active FROM details WHERE status = 'Active'";
$activeCountResult = mysqli_query($connection, $activeCountQuery);
$activeCount = mysqli_fetch_assoc($activeCountResult)['Active'];


$inactiveCountQuery = "SELECT COUNT(*) as inactive FROM details WHERE status = 'inactive'";
$inactiveCountResult = mysqli_query($connection, $inactiveCountQuery);
$inactiveCount = mysqli_fetch_assoc($inactiveCountResult)['inactive'];


$totalCountQuery = "SELECT COUNT(*) as total FROM details";
$totalCountResult = mysqli_query($connection, $totalCountQuery);
$totalCountData = mysqli_fetch_assoc($totalCountResult);
$totalCount = $totalCountData['total'];






// Fetch all details
// $detailsSql = "SELECT * FROM details";
// $detailsResult = mysqli_query($connection, $detailsSql);


 // Number of items per page
 $itemsPerPage = 10;

 // Get the current page number from the URL, default to page 1 if not set
 $page = isset($_GET['page']) ? $_GET['page'] : 1;

 // Calculate the offset for the query based on the current page number
 $offset = ($page - 1) * $itemsPerPage;

 // Fetch details with pagination
 $detailsSql = "SELECT * FROM details ORDER BY id DESC LIMIT $itemsPerPage OFFSET $offset";
 $detailsResult = mysqli_query($connection, $detailsSql);

?>






















<?php include('header.php') ?>



            <div class="app-main__outer">
                <div class="app-main__inner">
                    <!-- <div class="app-page-title">
                        <div class="page-title-wrapper">
                            <div class="page-title-heading">
                                <div class="page-title-icon">
                                    <i class="fa fa-dashboard" style="font-size:24px"></i>
                                </div>
                                <div>Analytics Dashboard
                                    <div class="page-title-subheading">This is an example dashboard created using
                                        build-in elements and components.
                                    </div>
                                </div>
                            </div>
                            <div class="page-title-actions">
                                <button type="button" data-toggle="tooltip" title="Example Tooltip"
                                    data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                                    <i class="fa fa-star"></i>
                                </button>
                                <div class="d-inline-block dropdown">
                                    <button type="button" data-toggle="dropdown" aria-haspopup="true"
                                        aria-expanded="false" class="btn-shadow dropdown-toggle btn btn-info">
                                        <span class="btn-icon-wrapper pr-2 opacity-7">
                                            <i class="fa fa-business-time fa-w-20"></i>
                                        </span>
                                        Buttons
                                    </button>
                                    <div tabindex="-1" role="menu" aria-hidden="true"
                                        class="dropdown-menu dropdown-menu-right">
                                        <ul class="nav flex-column">
                                            <li class="nav-item">
                                                <a href="javascript:void(0);" class="nav-link">
                                                    <i class="nav-link-icon lnr-inbox"></i>
                                                    <span>
                                                        Inbox
                                                    </span>
                                                    <div class="ml-auto badge badge-pill badge-secondary">86</div>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="javascript:void(0);" class="nav-link">
                                                    <i class="nav-link-icon lnr-book"></i>
                                                    <span>
                                                        Book
                                                    </span>
                                                    <div class="ml-auto badge badge-pill badge-danger">5</div>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="javascript:void(0);" class="nav-link">
                                                    <i class="nav-link-icon lnr-picture"></i>
                                                    <span>
                                                        Picture
                                                    </span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a disabled href="javascript:void(0);" class="nav-link disabled">
                                                    <i class="nav-link-icon lnr-file-empty"></i>
                                                    <span>
                                                        File Disabled
                                                    </span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <div class="row">
                        <div class="col-md-6 col-xl-4">
                            <div class="card mb-3 widget-content">
                                <div class="widget-content-outer">
                                    <div class="widget-content-wrapper">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Total Properties</div>
                                            <div class="widget-subheading">For Sale </div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-warning"><?php echo $totalCount; ?> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-4">
                            <div class="card mb-3 widget-content">
                                <div class="widget-content-outer">
                                    <div class="widget-content-wrapper">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Sale</div>
                                            <div class="widget-subheading">For Sale </div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-warning"><?php echo $activeCount; ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-4">
                            <div class="card mb-3 widget-content">
                                <div class="widget-content-outer">
                                    <div class="widget-content-wrapper">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Properties Sold</div>
                                            <div class="widget-subheading"> Solde Properties </div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-danger"><?php echo $inactiveCount; ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-xl-none d-lg-block col-md-6 col-xl-4">
                            <div class="card mb-3 widget-content">
                                <div class="widget-content-outer">
                                    <div class="widget-content-wrapper">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Income</div>
                                            <div class="widget-subheading">Expected totals</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-focus">$147</div>
                                        </div>
                                    </div>
                                    <div class="widget-progress-wrapper">
                                        <div class="progress-bar-sm progress-bar-animated-alt progress">
                                            <div class="progress-bar bg-info" role="progressbar" aria-valuenow="54"
                                                aria-valuemin="0" aria-valuemax="100" style="width: 54%;"></div>
                                        </div>
                                        <div class="progress-sub-label">
                                            <div class="sub-label-left">Expenses</div>
                                            <div class="sub-label-right">100%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                     
                        <div class="col-md-12 col-lg-12">
                            <div class="mb-3 card">
                                <div class="card-header-tab card-header">
                                    <div class="card-header-title">
                                        <i class="header-icon lnr-rocket icon-gradient bg-tempting-azure"> </i>
                                      ADD  PROPERTY 
                                    </div>
                                    <div class="btn-actions-pane-right">
                                        <div class="nav">
                                            <!-- <a href="javascript:void(0);"
                                                class="border-0 btn-pill btn-wide btn-transition active btn btn-outline-alternate">Tab
                                                1</a>
                                            <a href="javascript:void(0);"
                                                class="ml-1 btn-pill btn-wide border-0 btn-transition  btn btn-outline-alternate second-tab-toggle-alt">Tab
                                                2</a> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content">
                                    <div class="tab-pane fade active show" id="tab-eg-55">
                                    
                                        <div class="pt-2 card-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="title" class="form-label">Title:</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="status" class="form-label">Status:</label>
                    <select name="status" class="form-select form-control" required>
                        <option value="Active" >Sale</option>
                        <option value="Inactive">Solde</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="remark" class="form-label">Remark:</label>
                    <!-- <textarea name="remark" class="form-control"></textarea> -->





                    <!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
    </head>
    <body>
        <style>
            #container {
                width: 1000px;
                margin: 20px auto;
            }
            .ck-editor__editable[role="textbox"] {
                /* editing area */
                min-height: 200px;
            }
            .ck-content .image {
                /* block images */
                max-width: 80%;
                margin: 20px auto;
            }
        </style>
        <div id="container">
            <textarea id="editor" name="remark">
            </textarea>
        </div>
        <!--
            The "super-build" of CKEditor&nbsp;5 served via CDN contains a large set of plugins and multiple editor types.
            See https://ckeditor.com/docs/ckeditor5/latest/installation/getting-started/quick-start.html#running-a-full-featured-editor-from-cdn
        -->
        <script src="https://cdn.ckeditor.com/ckeditor5/40.1.0/super-build/ckeditor.js"></script>
        <!--
            Uncomment to load the Spanish translation
            <script src="https://cdn.ckeditor.com/ckeditor5/40.1.0/super-build/translations/es.js"></script>
        -->
        <script>
            // This sample still does not showcase all CKEditor&nbsp;5 features (!)
            // Visit https://ckeditor.com/docs/ckeditor5/latest/features/index.html to browse all the features.
            CKEDITOR.ClassicEditor.create(document.getElementById("editor"), {
                // https://ckeditor.com/docs/ckeditor5/latest/features/toolbar/toolbar.html#extended-toolbar-configuration-format
                toolbar: {
                    items: [
                        'exportPDF','exportWord', '|',
                        'findAndReplace', 'selectAll', '|',
                        'heading', '|',
                        'bold', 'italic', 'strikethrough', 'underline', 'code', 'subscript', 'superscript', 'removeFormat', '|',
                        'bulletedList', 'numberedList', 'todoList', '|',
                        'outdent', 'indent', '|',
                        'undo', 'redo',
                        '-',
                        'fontSize', 'fontFamily', 'fontColor', 'fontBackgroundColor', 'highlight', '|',
                        'alignment', '|',
                        'link', 'insertImage', 'blockQuote', 'insertTable', 'mediaEmbed', 'codeBlock', 'htmlEmbed', '|',
                        'specialCharacters', 'horizontalLine', 'pageBreak', '|',
                        'textPartLanguage', '|',
                        'sourceEditing'
                    ],
                    shouldNotGroupWhenFull: true
                },
                // Changing the language of the interface requires loading the language file using the <script> tag.
                // language: 'es',
                list: {
                    properties: {
                        styles: true,
                        startIndex: true,
                        reversed: true
                    }
                },
                // https://ckeditor.com/docs/ckeditor5/latest/features/headings.html#configuration
                heading: {
                    options: [
                        { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                        { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                        { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
                        { model: 'heading3', view: 'h3', title: 'Heading 3', class: 'ck-heading_heading3' },
                        { model: 'heading4', view: 'h4', title: 'Heading 4', class: 'ck-heading_heading4' },
                        { model: 'heading5', view: 'h5', title: 'Heading 5', class: 'ck-heading_heading5' },
                        { model: 'heading6', view: 'h6', title: 'Heading 6', class: 'ck-heading_heading6' }
                    ]
                },
                // https://ckeditor.com/docs/ckeditor5/latest/features/editor-placeholder.html#using-the-editor-configuration
                placeholder: 'Welcome to CKEditor&nbsp;5!',
                // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-family-feature
                fontFamily: {
                    options: [
                        'default',
                        'Arial, Helvetica, sans-serif',
                        'Courier New, Courier, monospace',
                        'Georgia, serif',
                        'Lucida Sans Unicode, Lucida Grande, sans-serif',
                        'Tahoma, Geneva, sans-serif',
                        'Times New Roman, Times, serif',
                        'Trebuchet MS, Helvetica, sans-serif',
                        'Verdana, Geneva, sans-serif'
                    ],
                    supportAllValues: true
                },
                // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-size-feature
                fontSize: {
                    options: [ 10, 12, 14, 'default', 18, 20, 22 ],
                    supportAllValues: true
                },
                // Be careful with the setting below. It instructs CKEditor to accept ALL HTML markup.
                // https://ckeditor.com/docs/ckeditor5/latest/features/general-html-support.html#enabling-all-html-features
                htmlSupport: {
                    allow: [
                        {
                            name: /.*/,
                            attributes: true,
                            classes: true,
                            styles: true
                        }
                    ]
                },
                // Be careful with enabling previews
                // https://ckeditor.com/docs/ckeditor5/latest/features/html-embed.html#content-previews
                htmlEmbed: {
                    showPreviews: true
                },
                // https://ckeditor.com/docs/ckeditor5/latest/features/link.html#custom-link-attributes-decorators
                link: {
                    decorators: {
                        addTargetToExternalLinks: true,
                        defaultProtocol: 'https://',
                        toggleDownloadable: {
                            mode: 'manual',
                            label: 'Downloadable',
                            attributes: {
                                download: 'file'
                            }
                        }
                    }
                },
                // https://ckeditor.com/docs/ckeditor5/latest/features/mentions.html#configuration
                mention: {
                    feeds: [
                        {
                            marker: '@',
                            feed: [
                                '@apple', '@bears', '@brownie', '@cake', '@cake', '@candy', '@canes', '@chocolate', '@cookie', '@cotton', '@cream',
                                '@cupcake', '@danish', '@donut', '@dragée', '@fruitcake', '@gingerbread', '@gummi', '@ice', '@jelly-o',
                                '@liquorice', '@macaroon', '@marzipan', '@oat', '@pie', '@plum', '@pudding', '@sesame', '@snaps', '@soufflé',
                                '@sugar', '@sweet', '@topping', '@wafer'
                            ],
                            minimumCharacters: 1
                        }
                    ]
                },
                // The "super-build" contains more premium features that require additional configuration, disable them below.
                // Do not turn them on unless you read the documentation and know how to configure them and setup the editor.
                removePlugins: [
                    // These two are commercial, but you can try them out without registering to a trial.
                    // 'ExportPdf',
                    // 'ExportWord',
                    'AIAssistant',
                    'CKBox',
                    'CKFinder',
                    'EasyImage',
                    // This sample uses the Base64UploadAdapter to handle image uploads as it requires no configuration.
                    // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/base64-upload-adapter.html
                    // Storing images as Base64 is usually a very bad idea.
                    // Replace it on production website with other solutions:
                    // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/image-upload.html
                    // 'Base64UploadAdapter',
                    'RealTimeCollaborativeComments',
                    'RealTimeCollaborativeTrackChanges',
                    'RealTimeCollaborativeRevisionHistory',
                    'PresenceList',
                    'Comments',
                    'TrackChanges',
                    'TrackChangesData',
                    'RevisionHistory',
                    'Pagination',
                    'WProofreader',
                    // Careful, with the Mathtype plugin CKEditor will not load when loading this sample
                    // from a local file system (file://) - load this site via HTTP server if you enable MathType.
                    'MathType',
                    // The following features are part of the Productivity Pack and require additional license.
                    'SlashCommand',
                    'Template',
                    'DocumentOutline',
                    'FormatPainter',
                    'TableOfContents',
                    'PasteFromOfficeEnhanced'
                ]
            });
        </script>
    </body>
</html>


                    
                </div>

                <div class="mb-3">
                    <label for="images" class="form-label">Select Images:</label>
                    <input type="file" name="images[]" class="form-control" accept="image/*" multiple required>
                </div>

                <button type="submit" class="btn btn-primary">Upload</button>
            </form>     
                                                </div>
                                             
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                  
                    <div class="row" id="property-section">
                        <div class="col-md-12">
                            <div class="main-card mb-3 card">
                                <div class="card-header">Property
                                    <div class="btn-actions-pane-right">
                                        <div role="group" class="btn-group-sm btn-group">
                                            <!-- <button class="active btn btn-focus">Last Week</button>
                                            <button class="btn btn-focus">All Month</button> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="align-middle mb-0 table table-borderless table-striped table-hover">
                                        <thead>
                                            <tr>
                                            <th class="text-center"></th>
                                                <th class="text-center">#</th>
                                                <th>Title</th>
                                                <!-- <th class="text-center">Remark</th> -->
                                                <th class="text-center">Status</th>
                                                <th class="text-center">Create</th>
                                                <th class="text-center">Update</th>
                                                <th class="text-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody class="p-3">
                                     
                                          
                                            <?php
                if (mysqli_num_rows($detailsResult) > 0) {
                    while ($row = mysqli_fetch_assoc($detailsResult)) {
                        echo "<tr>";
                        echo "<td></td>";
                        echo "<td>{$row['id']}</td>";

                        echo "<td>{$row['title']}</td>";
                        // echo "<td>{$row['remark']}</td>";
                        if($row['status'] == 'Active'){
                            echo "<td> <div class='badge badge-success'>{$row['status']}</div></td>";
                        }else{
                            echo "<td> <div class='badge badge-danger'>{$row['status']}</div></td>";
                        }
                      
                        echo "<td>{$row['created_at']}</td>";
                        echo "<td>{$row['updated_at']}</td>";
                        echo "<td>";
                        echo "<a href='view.php?id={$row['id']}' class='btn btn-info'>View</a> ";
                        echo "<a href='edit.php?id={$row['id']}' class='btn btn-warning'>Edit</a> ";
                        echo "<a href='delete.php?id={$row['id']}' class='btn btn-danger'>Delete</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No details found.</td></tr>";
                }
                ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="d-block text-center card-footer">
                                <!-- <nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">Next</a></li>
  </ul>
</nav> -->



<nav aria-label="Page navigation">
            <ul class="pagination">
                <?php
                // Calculate the total number of pages
                $totalRows = mysqli_num_rows(mysqli_query($connection, "SELECT * FROM details"));
                $totalPages = ceil($totalRows / $itemsPerPage);

                for ($i = 1; $i <= $totalPages; $i++) :
                ?>
                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>#property-section"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>


                                </div>
                            </div>
                        </div>
                    </div>
                  
                </div>
              
            </div>





            <?php include('footer.php') ?>

          







